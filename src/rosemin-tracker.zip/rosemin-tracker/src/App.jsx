import { useState, useEffect } from "react";

const DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const DAY_SHORTS = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];

const WORKOUT_TYPES = [
  { type: "glutes",  label: "🍑 Glutes",           cal: 1800, p: 135, c: 155, f: 45 },
  { type: "upper",   label: "💪 Upper Body",        cal: 1650, p: 125, c: 120, f: 50 },
  { type: "tennis",  label: "🎾 Tennis + Pilates",  cal: 1750, p: 125, c: 145, f: 50 },
  { type: "pilates", label: "🧘 Pilates",           cal: 1600, p: 125, c: 100, f: 50 },
  { type: "rest",    label: "🚶 Rest / Walk",       cal: 1550, p: 125, c: 90,  f: 45 },
];

const DEFAULT_TYPES = ["glutes","upper","tennis","glutes","upper","pilates","rest"];

const GRAB_GO_CATEGORIES = [
  {
    label: "🥩 Proteins",
    items: [
      { name: "Spiced Yogurt Chicken",            cal: 220, p: 42, c: 4,  f: 4,  emoji: "🔥", note: "2 lbs breast → ~5 servings" },
      { name: "Hot Honey Chicken (5–6oz)",         cal: 210, p: 33, c: 8,  f: 4,  emoji: "🍯" },
      { name: "Low Carb Taco Chicken (5–6oz)",     cal: 190, p: 33, c: 2,  f: 5,  emoji: "🌮" },
      { name: "Sheet Pan Kofta – Beef (÷4)",       cal: 255, p: 28, c: 3,  f: 15, emoji: "🥩" },
      { name: "Sheet Pan Kofta – Chicken (÷4)",    cal: 210, p: 30, c: 3,  f: 9,  emoji: "🍗" },
      { name: "BBQ Shredded Chicken (5–6oz)",      cal: 215, p: 33, c: 8,  f: 4,  emoji: "🍖" },
      { name: "Turkey Meatballs (6oz portion)",     cal: 210, p: 34, c: 1,  f: 8,  emoji: "🍡", note: "2lb batch ÷ ~5 servings" },
      { name: "Taco Chicken – Elote Bowl (5–6oz)", cal: 195, p: 33, c: 2,  f: 5,  emoji: "🌽" },
      { name: "Mediterranean Chicken (5–6oz)",     cal: 230, p: 33, c: 2,  f: 9,  emoji: "🍋" },
      { name: "Spaghetti Squash Chicken (5–6oz)",  cal: 200, p: 33, c: 4,  f: 5,  emoji: "🍝" },
      { name: "Oat Crust Pizza – Classic (½)",     cal: 310, p: 38, c: 18, f: 11, emoji: "🍕" },
    ]
  },
  {
    label: "🍚 Carb Sides",
    items: [
      { name: "Cauli Rice Blend (¾c cauli + ½c rice)",  cal: 130, p: 4,  c: 26, f: 1,  emoji: "🌾" },
      { name: "Air Fried Potatoes (½ batch)",            cal: 155, p: 4,  c: 28, f: 4,  emoji: "🥔", note: "~2 servings, ~78 cal each" },
      { name: "Carbé Diem Pasta (1 srv / 2oz dry)",      cal: 110, p: 8,  c: 40, f: 1,  emoji: "🍝", note: "16g net carbs after 24g fiber" },
      { name: "Spaghetti Squash (½ medium, roasted)",    cal: 75,  p: 2,  c: 17, f: 1,  emoji: "🎃", note: "~2 cups forked" },
    ]
  },
  {
    label: "🥦 Veggie Sides",
    items: [
      { name: "Roasted Green Beans",                     cal: 55,  p: 2,  c: 8,  f: 2,  emoji: "🫛", note: "~1.5 cups, light olive oil" },
      { name: "Roasted Broccoli",                        cal: 65,  p: 4,  c: 8,  f: 3,  emoji: "🥦", note: "~1.5 cups, light olive oil" },
    ]
  },
  {
    label: "🥣 Sauces & Toppings",
    items: [
      { name: "Rao's Marinara (1 srv / ½ cup)",          cal: 100, p: 2,  c: 10, f: 6,  emoji: "🍅" },
      { name: "Rao's Alfredo (1 srv / ¼ cup)",           cal: 100, p: 2,  c: 1,  f: 10, emoji: "🤍" },
      { name: "TJ's Harvest Sauce (1 srv / ½ cup)",      cal: 120, p: 1,  c: 14, f: 7,  emoji: "🍂" },
      { name: "Tahini 2 tbsp (Sunny Fine)",              cal: 90,  p: 3,  c: 3,  f: 8,  emoji: "🫙" },
      { name: "Spicy Harissa Hummus 2 tbsp",             cal: 60,  p: 2,  c: 5,  f: 4,  emoji: "🌶️" },
      { name: "Cottage Cheese Elote (÷5 bowls)",         cal: 55,  p: 5,  c: 5,  f: 2,  emoji: "🌽", note: "Per bowl portion" },
    ]
  },
  {
    label: "🥚 Basics",
    items: [
      { name: "2 Whole Eggs",                    cal: 140, p: 12, c: 1,  f: 10, emoji: "🥚" },
      { name: "3 Whole Eggs",                    cal: 210, p: 18, c: 1,  f: 15, emoji: "🥚" },
      { name: "2 Eggs + 3 Egg Whites",           cal: 175, p: 23, c: 1,  f: 10, emoji: "🍳", note: "Good protein boost with less fat" },
      { name: "Cottage Cheese ½ cup",            cal: 90,  p: 13, c: 5,  f: 2,  emoji: "🫙" },
      { name: "Cottage Cheese 1 cup",            cal: 180, p: 26, c: 10, f: 4,  emoji: "🫙" },
      { name: "½ Avocado",                       cal: 120, p: 1,  c: 6,  f: 11, emoji: "🥑", note: "Use sparingly — adds up on fat" },
      { name: "Electrolytes",                    cal: 10,  p: 0,  c: 2,  f: 0,  emoji: "💧", note: "Daily non-negotiable" },
      { name: "White Rice 1 cup (cooked)",        cal: 205, p: 4,  c: 45, f: 0,  emoji: "🍚" },
      { name: "Blackened Chicken (5–6oz)",        cal: 195, p: 35, c: 1,  f: 5,  emoji: "🫙", note: "Simple seasoned — pairs with anything" },
    ]
  },
  {
    label: "🥡 Grab & Go",
    items: [
      { name: "Subway Steak 6\"",          cal: 420, p: 28, c: 42, f: 14, emoji: "🥪" },
      { name: "Chipotle Chicken Bowl (full)", cal: 575, p: 43, c: 60, f: 15, emoji: "🌯" },
      { name: "Chipotle Bowl – Half Carbs",    cal: 425, p: 43, c: 30, f: 15, emoji: "🌯", note: "Full chicken + half rice/beans — save the rest" },
      { name: "Chipotle Chicken Protein Cup",  cal: 250, p: 38, c: 4,  f: 10, emoji: "🍗", note: "Chicken only, no base" },
      { name: "Luna Grill Chicken Bowl",   cal: 500, p: 40, c: 50, f: 16, emoji: "🥗" },
      { name: "Chick-fil-A Grilled",       cal: 320, p: 38, c: 13, f: 12, emoji: "🐔" },
      { name: "Greek Yogurt Protein Bowl",    cal: 380, p: 45, c: 25, f: 12, emoji: "🍓", note: "¾c Greek yogurt + protein powder + chia + milk" },
      { name: "Promix Bar",                 cal: 200, p: 20, c: 22, f: 6,  emoji: "⚡" },
      { name: "Nurri Shake",                 cal: 150, p: 30, c: 5,  f: 2,  emoji: "🥛", note: "Per serving" },
      { name: "Curry Chicken (Chopshop)",  cal: 510, p: 38, c: 52, f: 14, emoji: "🍛" },
    ]
  }
];

const SCHEDULE = {
  glutes:  [
    { time: "6:00",      label: "Wake + electrolytes",              icon: "💧" },
    { time: "7:00",      label: "Coffee + ½ bar",                   icon: "☕" },
    { time: "8:00–9:00", label: "Lift 🍑",                          icon: "🏋️‍♀️" },
    { time: "9:15",      label: "Protein + carbs + creatine",       icon: "🥩" },
    { time: "12:30",     label: "Lunch — protein + carbs + fiber",  icon: "🍽️" },
    { time: "3:30",      label: "Protein snack",                    icon: "🥚" },
    { time: "6:30",      label: "Dinner",                           icon: "🌙" },
    { time: "8:30",      label: "Magnesium + glycine",              icon: "✨" },
  ],
  upper:   [
    { time: "6:00",      label: "Wake + electrolytes",              icon: "💧" },
    { time: "7:00",      label: "Coffee + ½ bar",                   icon: "☕" },
    { time: "8:00–9:00", label: "Lift 💪",                          icon: "🏋️‍♀️" },
    { time: "9:15",      label: "Protein + carbs + creatine",       icon: "🥩" },
    { time: "12:30",     label: "Lunch — protein + carbs + fiber",  icon: "🍽️" },
    { time: "3:30",      label: "Protein snack",                    icon: "🥚" },
    { time: "6:30",      label: "Dinner",                           icon: "🌙" },
    { time: "8:30",      label: "Magnesium + glycine",              icon: "✨" },
  ],
  tennis:  [
    { time: "6:00",      label: "Wake + electrolytes",              icon: "💧" },
    { time: "7:00",      label: "Coffee + ½ bar",                   icon: "☕" },
    { time: "8:00–9:00", label: "Tennis 🎾",                        icon: "🎾" },
    { time: "9:30",      label: "Pilates (optional)",               icon: "🧘" },
    { time: "10:30",     label: "Protein + carbs",                  icon: "🥩" },
    { time: "1:30",      label: "Lunch — protein + carbs + fiber",  icon: "🍽️" },
    { time: "4:00",      label: "Snack",                            icon: "🥚" },
    { time: "6:30",      label: "Dinner",                           icon: "🌙" },
    { time: "8:30",      label: "Magnesium + glycine",              icon: "✨" },
  ],
  pilates: [
    { time: "6:00",      label: "Wake + electrolytes",              icon: "💧" },
    { time: "10:30",     label: "First meal — protein + fats",      icon: "🍽️" },
    { time: "1:30",      label: "Lunch — protein + carbs + fiber",  icon: "🥩" },
    { time: "4:00",      label: "Snack (if needed)",                icon: "🥚" },
    { time: "6:30",      label: "Dinner",                           icon: "🌙" },
    { time: "8:30",      label: "Magnesium + glycine",              icon: "✨" },
  ],
  rest:    [
    { time: "6:00",      label: "Wake + electrolytes",              icon: "💧" },
    { time: "10:30",     label: "First meal — protein + fats",      icon: "🍽️" },
    { time: "1:30",      label: "Lunch — protein + carbs + fiber",  icon: "🥩" },
    { time: "4:00",      label: "Snack (if needed)",                icon: "🥚" },
    { time: "6:30",      label: "Dinner",                           icon: "🌙" },
    { time: "8:30",      label: "Magnesium + glycine",              icon: "✨" },
  ],
};

const NONNEG = [
  { label: "Protein 110–130g",     icon: "🥩" },
  { label: "Creatine daily",       icon: "⚡" },
  { label: "Electrolytes daily",   icon: "💧" },
  { label: "Psyllium midday",      icon: "🌿" },
  { label: "Fuel before training", icon: "🔥" },
];

const SUPPLEMENTS = [
  { label: "Creatine 5g",          sub: "Post-workout / anytime",    icon: "⚡" },
  { label: "Omega-3 (Kion)",       sub: "With breakfast",            icon: "🐟" },
  { label: "Kion Aminos",          sub: "Pre-workout",               icon: "💊" },
  { label: "Magnesium (JS Health)",sub: "Before bed",                icon: "🌙" },
  { label: "Ritual Choline",       sub: "Morning with food",         icon: "🟡" },
  { label: "Just Thrive Probiotic",sub: "Morning — empty stomach",   icon: "🌿" },
  { label: "Nutrafol",             sub: "With largest meal",         icon: "💆" },
  { label: "Glycine",              sub: "Before bed with magnesium", icon: "✨" },
  { label: "Arrae",                sub: "As directed",               icon: "🫧" },
];

const TYPE_COLOR = {
  glutes: "#ff6b8a", upper: "#a78bfa", tennis: "#34d399", pilates: "#60a5fa", rest: "#94a3b8"
};

function MacroRing({ label, value, target, color }) {
  const r = 28, circ = 2 * Math.PI * r;
  const dash = Math.min(value / target, 1) * circ;
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
      <svg width={70} height={70} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={35} cy={35} r={r} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth={6} />
        <circle cx={35} cy={35} r={r} fill="none" stroke={color} strokeWidth={6}
          strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
          style={{ transition: "stroke-dasharray 0.5s ease" }} />
        <text x={35} y={38} textAnchor="middle" fill="white" fontSize={13} fontWeight="700"
          fontFamily="'DM Mono', monospace"
          style={{ transform: "rotate(90deg)", transformOrigin: "35px 35px" }}>{value}</text>
      </svg>
      <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", fontFamily: "'DM Mono', monospace", letterSpacing: 1, textTransform: "uppercase" }}>{label}</div>
      <div style={{ fontSize: 10, color, fontFamily: "'DM Mono', monospace" }}>/ {target}g</div>
    </div>
  );
}

function LogEntry({ entry, onDelete }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px", borderRadius: 10, background: "rgba(255,255,255,0.05)", marginBottom: 6, gap: 8 }}>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: "white", fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{entry.name}</div>
        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", fontFamily: "'DM Mono', monospace", marginTop: 2 }}>
          {entry.cal}cal · P{entry.p} · C{entry.c} · F{entry.f}
        </div>
      </div>
      <button onClick={onDelete} style={{ background: "rgba(255,100,100,0.15)", border: "none", borderRadius: 6, color: "#ff6b6b", cursor: "pointer", fontSize: 13, padding: "4px 8px" }}>✕</button>
    </div>
  );
}

// --- Storage helpers ---
function getWeekKey() {
  const now = new Date();
  const jan1 = new Date(now.getFullYear(), 0, 1);
  const week = Math.ceil(((now - jan1) / 86400000 + jan1.getDay() + 1) / 7);
  return `week-${now.getFullYear()}-${week}`;
}


const EMPTY_DAY = (type) => ({
  type, log: [], checks: Array(5).fill(false), supChecks: Array(9).fill(false)
});

export default function GluteTracker() {
  const todayIdx = (() => { const d = new Date().getDay(); return d === 0 ? 6 : d - 1; })();
  const weekKey = getWeekKey();

  const [selectedDay, setSelectedDay] = useState(todayIdx);
  const [weekData, setWeekData] = useState(() => {
    // Initialize all 7 days with defaults
    return Array.from({ length: 7 }, (_, i) => EMPTY_DAY(DEFAULT_TYPES[i]));
  });
  const [loaded, setLoaded] = useState(false);
  const [openDropdown, setOpenDropdown] = useState(null);
  const [tab, setTab] = useState("tracker");
  const [customName, setCustomName] = useState("");
  const [customCal, setCustomCal] = useState("");
  const [customP, setCustomP] = useState("");
  const [customC, setCustomC] = useState("");
  const [customF, setCustomF] = useState("");
  const [saveStatus, setSaveStatus] = useState(""); // "saving" | "saved" | ""

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(`tracker-${weekKey}`);
      if (saved) {
        setWeekData(JSON.parse(saved));
      }
    } catch (e) {
      // use defaults
    }
    setLoaded(true);
  }, [weekKey]);

  // Save to localStorage whenever weekData changes
  useEffect(() => {
    if (!loaded) return;
    try {
      localStorage.setItem(`tracker-${weekKey}`, JSON.stringify(weekData));
      setSaveStatus("saved");
      setTimeout(() => setSaveStatus(""), 1500);
    } catch (e) {
      setSaveStatus("");
    }
  }, [weekData, loaded]);

  // Current day's data — guard against undefined during initial load
  const dayData = weekData[selectedDay] || EMPTY_DAY(DEFAULT_TYPES[selectedDay]);
  const currentType = dayData.type || DEFAULT_TYPES[selectedDay];
  const log = dayData.log || [];
  const checks = dayData.checks || Array(5).fill(false);
  const supChecks = dayData.supChecks || Array(9).fill(false);

  const wt = WORKOUT_TYPES.find(w => w.type === currentType);
  const color = TYPE_COLOR[currentType];

  const totals = log.reduce((a, e) => ({ cal: a.cal + e.cal, p: a.p + e.p, c: a.c + e.c, f: a.f + e.f }), { cal: 0, p: 0, c: 0, f: 0 });
  const calPct = Math.min((totals.cal / wt.cal) * 100, 100);

  function updateDay(dayIdx, updater) {
    setWeekData(prev => prev.map((d, i) => i === dayIdx ? { ...d, ...updater(d) } : d));
  }

  function setDayType(dayIdx, type) {
    updateDay(dayIdx, () => ({ type }));
    setOpenDropdown(null);
  }

  function addQuick(item) {
    updateDay(selectedDay, d => ({ log: [...d.log, { ...item, id: Date.now() }] }));
  }

  function removeLog(id) {
    updateDay(selectedDay, d => ({ log: d.log.filter(e => e.id !== id) }));
  }

  function toggleCheck(i) {
    updateDay(selectedDay, d => ({ checks: d.checks.map((v, idx) => idx === i ? !v : v) }));
  }

  function toggleSupCheck(i) {
    updateDay(selectedDay, d => ({ supChecks: d.supChecks.map((v, idx) => idx === i ? !v : v) }));
  }

  function addCustom() {
    if (!customName || !customCal) return;
    updateDay(selectedDay, d => ({
      log: [...d.log, { id: Date.now(), name: customName, cal: +customCal||0, p: +customP||0, c: +customC||0, f: +customF||0 }]
    }));
    setCustomName(""); setCustomCal(""); setCustomP(""); setCustomC(""); setCustomF("");
  }

  const inputStyle = {
    background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)",
    borderRadius: 8, color: "white", padding: "8px 10px", fontSize: 13,
    fontFamily: "'DM Mono', monospace", outline: "none", width: "100%"
  };

  const tabStyle = (active) => ({
    flex: 1, padding: "10px 0", border: "none", borderRadius: 10,
    background: active ? "rgba(255,255,255,0.12)" : "transparent",
    color: active ? "white" : "rgba(255,255,255,0.4)",
    fontFamily: "'Plus Jakarta Sans', sans-serif",
    fontWeight: active ? 700 : 500, fontSize: 11, cursor: "pointer", transition: "all 0.2s"
  });

  if (!loaded) return (
    <div style={{ minHeight: "100vh", background: "#0d0d0f", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", fontSize: 13, letterSpacing: 2 }}>LOADING…</div>
    </div>
  );

  return (
    <div
      onClick={() => openDropdown !== null && setOpenDropdown(null)}
      style={{
        minHeight: "100vh", background: "#0d0d0f",
        fontFamily: "'Plus Jakarta Sans', sans-serif",
        backgroundImage: `radial-gradient(ellipse at 20% 0%, ${color}12 0%, transparent 55%), radial-gradient(ellipse at 80% 100%, rgba(167,139,250,0.05) 0%, transparent 55%)`,
        paddingBottom: 40
      }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=DM+Mono:wght@400;500&display=swap');
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 2px; }
        input::placeholder { color: rgba(255,255,255,0.2); }
      `}</style>

      {/* Header */}
      <div style={{ padding: "28px 20px 0", display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 11, letterSpacing: 3, color: "rgba(255,255,255,0.3)", textTransform: "uppercase", fontFamily: "'DM Mono', monospace", marginBottom: 4 }}>Glute Recomp Protocol</div>
          <div style={{ fontSize: 26, fontWeight: 800, color: "white", letterSpacing: -0.5 }}>Nutrition Tracker</div>
        </div>
        <div style={{ marginTop: 8, fontSize: 11, fontFamily: "'DM Mono', monospace", color: saveStatus === "saved" ? "#34d399" : "rgba(255,255,255,0.2)", transition: "color 0.3s" }}>
          {saveStatus === "saving" ? "saving…" : saveStatus === "saved" ? "✓ saved" : ""}
        </div>
      </div>

      {/* Day strip + dropdowns */}
      <div style={{ padding: "20px 20px 16px", overflowX: "auto" }}>
        <div style={{ display: "flex", gap: 8, minWidth: "max-content" }}>
          {DAY_SHORTS.map((short, i) => {
            const type = (weekData[i] || EMPTY_DAY(DEFAULT_TYPES[i])).type;
            const c = TYPE_COLOR[type];
            const wtype = WORKOUT_TYPES.find(w => w.type === type);
            const isSelected = selectedDay === i;
            const isOpen = openDropdown === i;

            return (
              <div key={i} style={{ position: "relative", display: "flex", flexDirection: "column", alignItems: "center" }}>
                {/* Day chip */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedDay(i);
                    
                    setOpenDropdown(null);
                  }}
                  style={{
                    padding: "10px 12px 8px", borderRadius: 12, border: "none", cursor: "pointer",
                    background: isSelected ? c : "rgba(255,255,255,0.06)",
                    color: isSelected ? "white" : "rgba(255,255,255,0.45)",
                    fontFamily: "'Plus Jakarta Sans', sans-serif",
                    fontWeight: isSelected ? 700 : 500, fontSize: 12,
                    transition: "all 0.2s",
                    boxShadow: isSelected ? `0 0 22px ${c}55` : "none",
                    display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
                    minWidth: 52
                  }}>
                  <div style={{ fontSize: 15 }}>{wtype.label.split(" ")[0]}</div>
                  <div style={{ letterSpacing: 0.5 }}>{short}</div>
                </button>

                {/* Dropdown toggle arrow */}
                <button
                  onClick={(e) => { e.stopPropagation(); setOpenDropdown(isOpen ? null : i); }}
                  style={{
                    marginTop: 4, width: 20, height: 20, borderRadius: "50%",
                    background: isOpen ? c : "rgba(255,255,255,0.12)",
                    border: "none", cursor: "pointer",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 8, color: "white", transition: "all 0.2s",
                    boxShadow: isOpen ? `0 0 8px ${c}80` : "none",
                    flexShrink: 0
                  }}>
                  {isOpen ? "▲" : "▼"}
                </button>

                {/* Dropdown */}
                {isOpen && (
                  <div
                    onClick={(e) => e.stopPropagation()}
                    style={{
                      position: "absolute", top: "calc(100% + 6px)", left: "50%", transform: "translateX(-50%)",
                      background: "#1c1c22", border: "1px solid rgba(255,255,255,0.13)",
                      borderRadius: 14, padding: "8px 6px", zIndex: 200, minWidth: 195,
                      boxShadow: "0 16px 48px rgba(0,0,0,0.7)"
                    }}>
                    <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", letterSpacing: 2, textTransform: "uppercase", padding: "4px 10px 8px" }}>
                      {DAY_NAMES[i]} workout
                    </div>
                    {WORKOUT_TYPES.map(wopt => {
                      const isActive = type === wopt.type;
                      return (
                        <button key={wopt.type} onClick={() => setDayType(i, wopt.type)}
                          style={{
                            width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between",
                            padding: "9px 12px", borderRadius: 9, border: "none", cursor: "pointer",
                            background: isActive ? `${TYPE_COLOR[wopt.type]}28` : "transparent",
                            color: isActive ? "white" : "rgba(255,255,255,0.6)",
                            fontFamily: "'Plus Jakarta Sans', sans-serif",
                            fontWeight: isActive ? 700 : 500, fontSize: 13,
                            transition: "all 0.15s", textAlign: "left", marginBottom: 2
                          }}>
                          <span>{wopt.label}</span>
                          <span style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 1 }}>
                            {isActive && <span style={{ color: TYPE_COLOR[wopt.type], fontSize: 11 }}>✓</span>}
                            <span style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace" }}>{wopt.cal}cal</span>
                          </span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Day card */}
      <div style={{ padding: "0 20px" }}>
        <div style={{ borderRadius: 18, padding: "18px 20px", background: `linear-gradient(135deg, ${color}22, ${color}08)`, border: `1px solid ${color}30`, transition: "all 0.3s" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
            <div>
              <div style={{ fontSize: 18, fontWeight: 800, color: "white" }}>{DAY_NAMES[selectedDay]}</div>
              <div style={{ fontSize: 13, color, fontWeight: 700, marginTop: 3 }}>{wt.label}</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", marginTop: 3 }}>P{wt.p} · C{wt.c} · F{wt.f}g</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 26, fontWeight: 800, color: "white", fontFamily: "'DM Mono', monospace" }}>{wt.cal}</div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", fontFamily: "'DM Mono', monospace", letterSpacing: 1 }}>TARGET CAL</div>
            </div>
          </div>
          <div style={{ background: "rgba(255,255,255,0.07)", borderRadius: 8, height: 8, marginBottom: 8, overflow: "hidden" }}>
            <div style={{ height: "100%", width: `${calPct}%`, background: color, borderRadius: 8, transition: "width 0.5s ease, background 0.3s" }} />
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "rgba(255,255,255,0.4)", fontFamily: "'DM Mono', monospace" }}>
            <span>{totals.cal} eaten</span>
            <span>{Math.max(0, wt.cal - totals.cal)} remaining</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ padding: "16px 20px 0" }}>
        <div style={{ display: "flex", background: "rgba(255,255,255,0.04)", borderRadius: 12, padding: 4, gap: 2 }}>
          {["tracker","schedule","quick-add","checklist","week"].map(t => (
            <button key={t} onClick={() => setTab(t)} style={tabStyle(tab === t)}>
              {{ tracker: "📊 Today", schedule: "⏰ Flow", "quick-add": "🚀 Add", checklist: "✅ Checks", week: "📅 Week" }[t]}
            </button>
          ))}
        </div>
      </div>

      <div style={{ padding: "16px 20px 0" }}>

        {/* TRACKER */}
        {tab === "tracker" && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-around", padding: "16px 0 20px", background: "rgba(255,255,255,0.03)", borderRadius: 16, marginBottom: 16 }}>
              <MacroRing label="Protein" value={totals.p} target={wt.p} color="#ff6b8a" />
              <MacroRing label="Carbs"   value={totals.c} target={wt.c} color="#fbbf24" />
              <MacroRing label="Fats"    value={totals.f} target={wt.f} color="#34d399" />
            </div>
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", letterSpacing: 2, textTransform: "uppercase", marginBottom: 10 }}>Food Log</div>
              {log.length === 0 && <div style={{ textAlign: "center", color: "rgba(255,255,255,0.2)", fontSize: 13, padding: "20px 0" }}>No entries yet — tap 🚀 Add to log meals</div>}
              {log.map(e => <LogEntry key={e.id} entry={e} onDelete={() => removeLog(e.id)} />)}
            </div>
            <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: 14, padding: 14 }}>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", letterSpacing: 2, textTransform: "uppercase", marginBottom: 10 }}>Add Custom</div>
              <input style={{ ...inputStyle, marginBottom: 8 }} placeholder="Food name" value={customName} onChange={e => setCustomName(e.target.value)} />
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 6, marginBottom: 10 }}>
                {[["Cal", customCal, setCustomCal],["P (g)", customP, setCustomP],["C (g)", customC, setCustomC],["F (g)", customF, setCustomF]].map(([ph, val, set]) => (
                  <input key={ph} style={inputStyle} placeholder={ph} value={val} onChange={e => set(e.target.value)} type="number" min="0" />
                ))}
              </div>
              <button onClick={addCustom} style={{ width: "100%", padding: 11, borderRadius: 10, border: "none", background: color, color: "white", fontWeight: 700, fontSize: 14, fontFamily: "'Plus Jakarta Sans', sans-serif", cursor: "pointer", boxShadow: `0 4px 16px ${color}40`, transition: "background 0.3s" }}>+ Add Entry</button>
            </div>
          </div>
        )}

        {/* SCHEDULE */}
        {tab === "schedule" && (
          <div>
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", letterSpacing: 2, textTransform: "uppercase", marginBottom: 14 }}>Daily Flow — {wt.label}</div>
            {(SCHEDULE[currentType] || SCHEDULE.rest).map((item, i) => (
              <div key={i} style={{ display: "flex", gap: 12, alignItems: "flex-start", padding: "12px 14px", borderRadius: 12, background: i % 2 === 0 ? "rgba(255,255,255,0.04)" : "transparent", marginBottom: 4 }}>
                <div style={{ fontSize: 18, minWidth: 24, textAlign: "center" }}>{item.icon}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: "white" }}>{item.label}</div>
                  <div style={{ fontSize: 11, color, fontFamily: "'DM Mono', monospace", marginTop: 2 }}>{item.time}</div>
                </div>
              </div>
            ))}
            <div style={{ marginTop: 16, background: `${color}12`, border: `1px solid ${color}25`, borderRadius: 14, padding: 14 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color, marginBottom: 8, fontFamily: "'DM Mono', monospace", letterSpacing: 1, textTransform: "uppercase" }}>Portion Guide</div>
              {currentType === "glutes" ? (
                <>
                  <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", marginBottom: 4 }}>🍚 1 cup rice/quinoa or large 🥔</div>
                  <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)" }}>🥩 Double meat portions</div>
                </>
              ) : (
                <>
                  <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", marginBottom: 4 }}>🍚 ½ cup rice/quinoa or small 🥔</div>
                  <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)" }}>🥩 Normal portions (or double + cut rice)</div>
                </>
              )}
            </div>
          </div>
        )}

        {/* QUICK ADD */}
        {tab === "quick-add" && (
          <div>
            {GRAB_GO_CATEGORIES.map((cat, ci) => (
              <div key={ci} style={{ marginBottom: 20 }}>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", letterSpacing: 2, textTransform: "uppercase", marginBottom: 10 }}>{cat.label}</div>
                {cat.items.map((item, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, padding: "11px 13px", borderRadius: 13, background: "rgba(255,255,255,0.05)", marginBottom: 7, border: "1px solid rgba(255,255,255,0.06)" }}>
                    <div style={{ fontSize: 22 }}>{item.emoji}</div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: "white", lineHeight: 1.3 }}>{item.name}</div>
                      {item.note && <div style={{ fontSize: 10, color, fontFamily: "'DM Mono', monospace", marginTop: 1 }}>{item.note}</div>}
                      <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", fontFamily: "'DM Mono', monospace", marginTop: 2 }}>{item.cal}cal · P{item.p} · C{item.c} · F{item.f}</div>
                    </div>
                    <button onClick={() => { addQuick(item); setTab("tracker"); }} style={{ padding: "7px 12px", borderRadius: 8, border: "none", background: color, color: "white", fontWeight: 700, fontSize: 12, fontFamily: "'Plus Jakarta Sans', sans-serif", cursor: "pointer", whiteSpace: "nowrap", flexShrink: 0, boxShadow: `0 2px 10px ${color}40`, transition: "background 0.3s" }}>+ Log</button>
                  </div>
                ))}
              </div>
            ))}
          </div>
        )}

        {/* WEEK SUMMARY */}
        {tab === "week" && (
          <div>
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", letterSpacing: 2, textTransform: "uppercase", marginBottom: 14 }}>This Week</div>
            {weekData.map((d, i) => {
              const wtype = WORKOUT_TYPES.find(w => w.type === d.type);
              const dc = TYPE_COLOR[d.type];
              const dt = d.log.reduce((a, e) => ({ cal: a.cal + e.cal, p: a.p + e.p, c: a.c + e.c }), { cal: 0, p: 0, c: 0 });
              const pct = Math.min((dt.cal / wtype.cal) * 100, 100);
              const isToday = i === todayIdx;
              const isSelected = i === selectedDay;
              return (
                <button key={i} onClick={() => { setSelectedDay(i); setTab("tracker"); }}
                  style={{ width: "100%", display: "flex", alignItems: "center", gap: 14, padding: "14px 16px", borderRadius: 14, border: "none", cursor: "pointer", background: isSelected ? `${dc}18` : "rgba(255,255,255,0.04)", marginBottom: 8, textAlign: "left", borderLeft: isSelected ? `3px solid ${dc}` : isToday ? `3px solid rgba(255,255,255,0.2)` : "3px solid transparent", transition: "all 0.2s" }}>
                  <div style={{ minWidth: 38 }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: isToday ? "white" : "rgba(255,255,255,0.5)", fontFamily: "'DM Mono', monospace" }}>{DAY_SHORTS[i]}</div>
                    {isToday && <div style={{ fontSize: 9, color: dc, fontFamily: "'DM Mono', monospace", letterSpacing: 1 }}>TODAY</div>}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                      <span style={{ fontSize: 12, color: dc, fontWeight: 600 }}>{wtype.label}</span>
                      <span style={{ fontSize: 12, fontFamily: "'DM Mono', monospace", color: dt.cal > 0 ? "white" : "rgba(255,255,255,0.25)" }}>{dt.cal > 0 ? `${dt.cal} cal` : "—"}</span>
                    </div>
                    <div style={{ background: "rgba(255,255,255,0.07)", borderRadius: 4, height: 5, overflow: "hidden" }}>
                      <div style={{ height: "100%", width: `${pct}%`, background: dc, borderRadius: 4, transition: "width 0.4s" }} />
                    </div>
                    {dt.cal > 0 && (
                      <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", marginTop: 4 }}>
                        P{dt.p} · C{dt.c} · {d.log.length} items · {d.checks.filter(Boolean).length}/5 habits · {d.supChecks.filter(Boolean).length}/10 supps
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {/* CHECKLIST */}
        {tab === "checklist" && (
          <div>
            {/* Non-Negotiables */}
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", letterSpacing: 2, textTransform: "uppercase", marginBottom: 12 }}>Non-Negotiables</div>
            {NONNEG.map((item, i) => (
              <button key={i} onClick={() => toggleCheck(i)}
                style={{ width: "100%", display: "flex", alignItems: "center", gap: 14, padding: "13px 16px", borderRadius: 13, border: "none", cursor: "pointer", background: checks[i] ? `${color}18` : "rgba(255,255,255,0.04)", marginBottom: 7, textAlign: "left", borderLeft: checks[i] ? `3px solid ${color}` : "3px solid transparent", transition: "all 0.2s" }}>
                <div style={{ width: 22, height: 22, borderRadius: 6, background: checks[i] ? color : "rgba(255,255,255,0.1)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, flexShrink: 0, transition: "all 0.2s", boxShadow: checks[i] ? `0 0 10px ${color}60` : "none" }}>{checks[i] ? "✓" : ""}</div>
                <div style={{ fontSize: 17 }}>{item.icon}</div>
                <div style={{ fontSize: 14, fontWeight: 600, color: checks[i] ? "white" : "rgba(255,255,255,0.5)", transition: "color 0.2s" }}>{item.label}</div>
              </button>
            ))}

            {/* Supplements */}
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", letterSpacing: 2, textTransform: "uppercase", margin: "20px 0 12px" }}>Daily Supplements</div>
            {SUPPLEMENTS.map((item, i) => (
              <button key={i} onClick={() => toggleSupCheck(i)}
                style={{ width: "100%", display: "flex", alignItems: "center", gap: 14, padding: "13px 16px", borderRadius: 13, border: "none", cursor: "pointer", background: supChecks[i] ? `${color}18` : "rgba(255,255,255,0.04)", marginBottom: 7, textAlign: "left", borderLeft: supChecks[i] ? `3px solid ${color}` : "3px solid transparent", transition: "all 0.2s" }}>
                <div style={{ width: 22, height: 22, borderRadius: 6, background: supChecks[i] ? color : "rgba(255,255,255,0.1)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, flexShrink: 0, transition: "all 0.2s", boxShadow: supChecks[i] ? `0 0 10px ${color}60` : "none" }}>{supChecks[i] ? "✓" : ""}</div>
                <div style={{ fontSize: 17 }}>{item.icon}</div>
                <div style={{ textAlign: "left" }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: supChecks[i] ? "white" : "rgba(255,255,255,0.5)", transition: "color 0.2s" }}>{item.label}</div>
                  <div style={{ fontSize: 11, color: supChecks[i] ? `${color}cc` : "rgba(255,255,255,0.25)", fontFamily: "'DM Mono', monospace", marginTop: 2 }}>{item.sub}</div>
                </div>
              </button>
            ))}

            {/* Totals */}
            <div style={{ marginTop: 20, display: "flex", gap: 10 }}>
              <div style={{ flex: 1, textAlign: "center", background: "rgba(255,255,255,0.03)", borderRadius: 14, padding: "14px 0" }}>
                <div style={{ fontSize: 24, fontWeight: 800, color, fontFamily: "'DM Mono', monospace" }}>{checks.filter(Boolean).length}/{NONNEG.length}</div>
                <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", letterSpacing: 1, textTransform: "uppercase", marginTop: 4 }}>Habits</div>
              </div>
              <div style={{ flex: 1, textAlign: "center", background: "rgba(255,255,255,0.03)", borderRadius: 14, padding: "14px 0" }}>
                <div style={{ fontSize: 24, fontWeight: 800, color, fontFamily: "'DM Mono', monospace" }}>{supChecks.filter(Boolean).length}/{SUPPLEMENTS.length}</div>
                <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", fontFamily: "'DM Mono', monospace", letterSpacing: 1, textTransform: "uppercase", marginTop: 4 }}>Supplements</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
